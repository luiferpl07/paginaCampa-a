import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';

const propuestas = [
  {
    id: 'protegiendo-a-los-mayores',
    title: 'Protegiendo a los Mayores',
    description: 'Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Donec rutrum congue leo eget malesuada. Curabitur',
    image: 'https://ext.same-assets.com/77511177/2240474230.jpeg',
  },
  {
    id: 'protegiendo',
    title: 'Protegiendo ',
    description: 'Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Proin eget tortor risus. Quisque velit nisi, pretium',
    image: 'https://ext.same-assets.com/77511177/1529725074.jpeg',
  },
  {
    id: 'creando-empleos',
    title: 'Creando Empleos',
    description: 'Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur aliquet quam id dui posuere blandit. Quisque velit',
    image: 'https://ext.same-assets.com/77511177/616072021.jpeg',
  },
  {
    id: 'creciendo-nuestra-economia',
    title: 'Creciendo Nuestra Economía',
    description: 'Cras ultricies ligula sed magna dictum porta. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Lorem ipsum',
    image: 'https://ext.same-assets.com/77511177/2446538560.jpeg',
  },
];


const SeccionPropuestas = () => {
  return (
    <section className="section-padding bg-gray-50">
      <div className="container-custom">
        <h2 className="section-title text-center mb-12">Las prioridades de Hector Olimpo</h2>
        <p className="text-center max-w-3xl mx-auto mb-12 text-gray-600">
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. In quia laudantium exercitationem libero porro animi saepe soluta eius minima, inventore odit, maxime impedit placeat illo repudiandae. Ipsum inventore quaerat veritatis?
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {propuestas.map((propuestas) => (
            <div key={propuestas.id} className="issue-card">
              <div className="relative">
                <Image
                  src={propuestas.image}
                  alt={propuestas.title}
                  width={360}
                  height={260}
                  className="issue-card-image"
                />
              </div>
              <div className="issue-card-content">
                <h3 className="issue-card-title">
                  <Link href={`/issues/${propuestas.id}`}>
                    {propuestas.title}
                  </Link>
                </h3>
                <p className="issue-card-text">{propuestas.description}</p>
                <Link href={`/issues/${propuestas.id}`} className="read-more-link">
                  Leer más <ArrowRight className="h-4 w-4 ml-1 inline" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SeccionPropuestas;
