"use client";

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from './ui/button';
import { Sheet, SheetTrigger, SheetContent } from './ui/sheet';
import { Menu } from 'lucide-react';

const navegacion = [
  {
    name: 'Home',
    href: '/',
    dropdown: [
      { name: 'Candidate Layout 1', href: '/' },
      { name: 'Candidate Layout 2', href: '/candidate-layout-2' },
      { name: 'Party Layout 1', href: '/party-layout-1' },
      { name: 'Party Layout 2', href: '/party-layout-2' },
    ]
  },
  {
    name: 'Paginas',
    href: '/meet-adam',
    dropdown: [
      { name: 'Acerca de', href: '/acerca-de' },
      { name: 'Contactos', href: '/contact' },
    ]
  },
  {
    name: 'Eventos',
    href: '/events',
    dropdown: [
      { name: 'Events Masonry', href: '/events' },
      { name: 'Events By Month', href: '/events/by-month' },
      { name: 'Events List With Map', href: '/events/with-map' },
    ]
  },
  {
    name: 'Media',
    href: '/media',
    dropdown: [
      { name: '2 Columns With Description', href: '/media/2-columns' },
      { name: '3 Columns', href: '/media/3-columns' },
      { name: '4 Columns Full Width', href: '/media/4-columns' },
      { name: 'Grid Gallery', href: '/media/grid-gallery' },
      { name: 'Instagram Gallery', href: '/media/instagram-gallery' },
    ]
  },
  {
    name: 'Features',
    href: '/features',
    dropdown: [
      { name: 'Shortcodes', href: '/features/shortcodes' },
      { name: 'Typography', href: '/features/typography' },
      { name: 'Columns', href: '/features/columns' },
    ]
  },
  {
    name: 'News',
    href: '/news',
    dropdown: [
      { name: 'News With Sidebar', href: '/news' },
      { name: 'News 2 Columns', href: '/news/2-columns' },
    ]
  },
];

const Header = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Get the hero section height to determine when to change header
      const heroSection = document.querySelector('.hero-section');
      if (!heroSection) return;
      
      const heroHeight = heroSection.getBoundingClientRect().height;
      
      // Check if we've scrolled past the hero section
      const isScrolled = window.scrollY > heroHeight - 100; // Subtract header height for a smooth transition
      
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    // Add scroll event listener
    window.addEventListener("scroll", handleScroll);
    
    // Check initial scroll position
    handleScroll();

    // Clean up event listener
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [scrolled]);

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-[#182b50] py-2 shadow-md' 
          : 'bg-transparent py-4'  
      }`}
    >
      <div className="container-custom">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="relative z-10">
            <div className="flex items-center">
              <Image
                src="/logo.png"
                alt="Logo"
                width={150}
                height={60}
                className={`transition-all duration-300 ${
                  scrolled ? 'h-12 md:h-14 py-1' : 'h-16 md:h-18 py-2'
                } w-auto`}
              />
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-4">
            <nav className="flex space-x-1">
              {navegacion.map((item) => (
                <div key={item.name} className="relative group">
                  <Link
                    href={item.href}
                    className={`nav-link px-3 inline-block text-sm font-bold uppercase transition-all duration-300 ${
                      scrolled ? 'py-5' : 'py-6'
                    }`}
                  >
                    {item.name}
                  </Link>
                  {item.dropdown && (
                    <div className="absolute left-0 mt-0 w-56 rounded-b-md bg-white shadow-lg transform opacity-0 group-hover:opacity-100 invisible group-hover:visible transition-all duration-300 z-20">
                      <div className="px-2 py-2 space-y-1">
                        {item.dropdown.map((subItem) => (
                          <Link
                            key={subItem.name}
                            href={subItem.href}
                            className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-primary"
                          >
                            {subItem.name}
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </nav>
            
            
          </div>

          {/* Mobile menu button */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" className="lg:hidden p-2 text-white">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-secondary text-white">
              <nav className="flex flex-col space-y-4 mt-8">
                {navegacion.map((item) => (
                  <div key={item.name} className="flex flex-col">
                    <Link
                      href={item.href}
                      className="text-white hover:text-primary py-2 text-base font-medium"
                    >
                      {item.name}
                    </Link>
                    {item.dropdown && (
                      <div className="pl-4 mt-2 space-y-2">
                        {item.dropdown.map((subItem) => (
                          <Link
                            key={subItem.name}
                            href={subItem.href}
                            className="block py-1 text-sm text-gray-300 hover:text-primary"
                          >
                            {subItem.name}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
                
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;