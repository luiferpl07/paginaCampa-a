import type { Metadata } from "next";
import { Inter, Lato, Open_Sans } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const lato = Lato({ weight: ["400", "700", "900"], subsets: ["latin"], variable: "--font-lato", display: "swap" });
const openSans = Open_Sans({ subsets: ["latin"], variable: "--font-open-sans", display: "swap" });

export const metadata: Metadata = {
  title: "Hector Olimpo",
  description: "Campaña política, partido, organización sin fines de lucro ",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={`${inter.variable} ${lato.variable} ${openSans.variable} font-open-sans`}>
        {children }
      </body>
    </html>
  );
}
