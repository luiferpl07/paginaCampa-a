import Layout from '@/components/Layout';
import SecciónPrincipal from '@/components/home/SecciónPrincipal';
import SeccionParticipacion from '@/components/home/SeccionParticipacion';
import SeccionPropuestas from '@/components/home/SeccionPropuestas';
import SecciónNoticias from '@/components/home/SecciónNoticias';
import SeccionPerfil from '@/components/home/SeccionPerfil';

export default function Home() {
  return (
    <Layout hasHero={true}>
      <SecciónPrincipal />
      <SeccionParticipacion />
      <SeccionPropuestas />
      <SecciónNoticias />
      <SeccionPerfil />
    </Layout>
  );
}